﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class animate : MonoBehaviour {

	//How fast player is right now
	float curSpeed;

	//which way player is facing
	bool goingRight;

	//Ground Check
	bool ground;

	//Is player scanning
	bool scan;
	KeyCode scanning = KeyCode.C;

	//Whick direction is player going
	KeyCode right = KeyCode.D;
	KeyCode left = KeyCode.A;

	//Find the Animator
	Animator anim;

	void Start () {
		anim = GetComponent<Animator> ();
	}

	void Update () {

		curSpeed = Input.GetAxis ("Horizontal");

		if (Input.GetKeyDown (right)) {
			goingRight = true;
		}
		if (Input.GetKeyDown (left)) {
			goingRight = false;
		}

		if (Input.GetKey (scanning)) {
			scan = true;
		} else {
			scan = false;
		}

		ground = GetComponentInParent<PlayerScript> ().grounded;

		anim.SetFloat ("moving", curSpeed);
		anim.SetBool ("scanning", scan);
		anim.SetBool ("grounded", ground);
		anim.SetBool ("facingRight", goingRight);
	}
}
