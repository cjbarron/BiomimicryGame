﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rabbit : MonoBehaviour{

	public float speed = 0.3f;
	public float jump = 5f;



}