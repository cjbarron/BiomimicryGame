﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour{

	public float speed = 0.2f;

	//public Rigidbody rb;

}
