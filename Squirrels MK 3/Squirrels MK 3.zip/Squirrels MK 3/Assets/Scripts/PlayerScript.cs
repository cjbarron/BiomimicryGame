﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

	//Animator anim1;

	//public bool showObject, hideObject;
	//public GameObject objectToShow, objectToHide;

	//Keys
	public KeyCode right = KeyCode.D;
	public KeyCode left = KeyCode.A;
	public KeyCode jump = KeyCode.Space;
	public KeyCode up = KeyCode.W;
	public KeyCode down = KeyCode.S;
	public KeyCode scan = KeyCode.C;

	//KeysForAnimals
	//public KeyCode RO = KeyCode.F1;
	//public KeyCode SL = KeyCode.F2;
	//public KeyCode RT = KeyCode.F3;
	//public KeyCode BD = KeyCode.F4;

	//InteractionKey
	public KeyCode interact = KeyCode.E;

	//AnimalClasses
	public GameObject robo;
	public GameObject squirrel;
	public GameObject rabbit;
	public GameObject bird;

	
	//Moving - Values
	float curSpeed;
	float AcelSpeed;
	float Speed;
	float upSpeed;

	//Jump
	float jumpPower;
	private float velocity;
	private Vector3 input;
	private Rigidbody rigbody;

	//RangeForChecks
	public float checkRange = 0.1f;
	public float scanRange = 1f;

	//GroundCheck
	public Transform groundCheck;
	public LayerMask whatIsGround;
	public bool grounded;

	//DirtCheck
	public LayerMask whatIsDirt;
	public bool dirted;

	//WallCheck
	public Transform wallCheck;
	public LayerMask whatIsClimable;
	public bool climable;
	public bool climbing;

	//AnimalCheck
	public LayerMask whatIsAnimal;

	//AnimalStates
	public enum Animal 
	{
		Robo,
		Squirrel,
		Bird,
		Rabbit
	}
	public Animal curAnimal = Animal.Robo;

	void Start () {
		rigbody = GetComponent<Rigidbody> ();
		//anim1 = GetComponentInChildren<Animator> ();

		AcelSpeed = 0.3f;
		jumpPower = 7f;


	}

	void Update () {
		/*if (Input.GetKeyDown (RO)) {
			curAnimal = Animal.Robo;
		}
		if (Input.GetKeyDown (SL)) {
			curAnimal = Animal.Squirrel;
		}
		if (Input.GetKeyDown (RT)) {
			curAnimal = Animal.Rabbit;
		}
		if (Input.GetKeyDown (BD)) {
			curAnimal = Animal.Bird;
		}*/

		switch (curAnimal) {
		case(Animal.Robo):
			rigbody.useGravity = true;

			robo.SetActive (true);
			squirrel.SetActive (false);
			rabbit.SetActive (false);
			bird.SetActive (false);

			Move ();
			CheckGround ();
			TheJump ();
			break;

		case(Animal.Squirrel):
			rigbody.useGravity = true;
			//AcelSpeed = squirrel.speed;
			//jumpPower = squirrel.jump;

			upSpeed = 0.3f;

			robo.SetActive (false);
			squirrel.SetActive (true);
			rabbit.SetActive (false);
			bird.SetActive (false);

			Move ();
			CheckGround ();
			CheckTree ();
			break;

		case(Animal.Rabbit):
			rigbody.useGravity = true;

			robo.SetActive (false);
			squirrel.SetActive (false);
			rabbit.SetActive (true);
			bird.SetActive (false);

			Move ();
			TheDirt ();
			CheckGround ();
			TheJump ();
			Digging ();
			break;

		case(Animal.Bird):
			rigbody.useGravity = false;
			upSpeed = 0.3f;

			robo.SetActive (false);
			squirrel.SetActive (false);
			rabbit.SetActive (false);
			bird.SetActive (true);

			Fly ();
			break;
		}

		if (Input.GetKey (scan)) {
			
			Scan ();
		}
	}

	public void Move(){

		curSpeed = Input.GetAxis ("Horizontal");
		Speed = curSpeed*AcelSpeed;

		transform.Translate (Speed, 0, 0);
	}

	public void Fly(){

		if (Input.GetKey (right)) {
			transform.Translate (upSpeed, 0, 0);
		} else if (Input.GetKey (left)) {
			transform.Translate (-upSpeed, 0, 0);
		}

		if (Input.GetKey (up)) {
			transform.Translate (0, upSpeed, 0);
		} else if (Input.GetKey (down)) {
			transform.Translate (0, -upSpeed, 0);
		}

	}

	public void CheckGround(){

		Collider [] groundCollider = Physics.OverlapSphere (groundCheck.position, checkRange, whatIsGround);
		Collider [] dirtCollider = Physics.OverlapSphere (groundCheck.position, checkRange, whatIsDirt);

		if (groundCollider.Length > 0 || dirtCollider.Length > 0) {
			grounded = true;
		} else {
			grounded = false;
		}

		//anim1.SetBool ("grounded", grounded);

	}

	//finds the current x coordinate
	//Checks to see if grounded AND for jump key to be pressed
	//adds velocity to rigidbody, using a vector with the current x coordinate and the jumpPower value for the y coordinate
	//z axis isn't used so left at 0
	public void TheJump(){

		input.x = Input.GetAxis ("Horizontal");

		if (Input.GetKeyDown (jump) && grounded) {
			rigbody.velocity = new Vector3 (input.x, jumpPower, 0f);

		}
	}

	//checks if standing on dirt
	//gets co-ordinates of twin dirt
	//checks for interact button, and sends player to twin dirt
	public void TheDirt(){

		Collider[] dirtCollider = Physics.OverlapSphere (groundCheck.position, checkRange, whatIsDirt);

		if (dirtCollider.Length > 0) {
			dirted = true;
			input.y = dirtCollider [0].GetComponent<Dirt> ().Other.transform.position.y;
			input.x = dirtCollider [0].GetComponent<Dirt> ().Other.transform.position.x;
		} else {
			dirted = false;
		}

		if (Input.GetKeyDown (interact) && dirted) {
			transform.position = new Vector3 (input.x, input.y + 2, 0);
		}
	}

	public void Digging(){
		
		Collider[] dirtCollider = Physics.OverlapSphere (groundCheck.position, checkRange, whatIsDirt);

		if (dirtCollider.Length > 0) {
			
		}

	}

	//Checks for climbable object and relavent input, then allows upward movement
	public void CheckTree(){

		Collider[] treeCollider = Physics.OverlapSphere (wallCheck.position, checkRange, whatIsClimable);

		if (treeCollider.Length > 0) {
			rigbody.velocity = new Vector3 (0, 0, 0);
			rigbody.useGravity = false;

			if (Input.GetKey (up)) {
				transform.Translate (0, upSpeed, 0);
			} else if (Input.GetKey (down)) {
				transform.Translate (0, -upSpeed, 0);
			}

		} else {
			rigbody.useGravity = true;
		}

	}

	public void Scan(){

		Collider[] AnimalsDetected = Physics.OverlapSphere (wallCheck.position, scanRange, whatIsAnimal);

		if (AnimalsDetected.Length > 0) {
			if (AnimalsDetected [0].gameObject.tag == "Squirrel") {
				curAnimal = Animal.Squirrel;
			}
			else if (AnimalsDetected [0].gameObject.tag == "Rabbit") {
				curAnimal = Animal.Rabbit;
			}
			else if (AnimalsDetected [0].gameObject.tag == "Bird") {
				curAnimal = Animal.Bird;
			}
			else if (AnimalsDetected [0].gameObject.tag == "Robo") {
				curAnimal = Animal.Robo;
			}
		}

	}
		
}
