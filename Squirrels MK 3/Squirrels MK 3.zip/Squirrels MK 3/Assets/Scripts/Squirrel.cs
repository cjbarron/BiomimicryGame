﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Squirrel : MonoBehaviour {

	public float speed = 0.2f;
	public float upSpeed = 0.1f;
	public float jump = 5f;

}
